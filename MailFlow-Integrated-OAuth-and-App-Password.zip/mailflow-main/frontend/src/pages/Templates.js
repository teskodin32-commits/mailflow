import React, { useState, useEffect, useRef } from 'react';
import { getTemplates, createTemplate, updateTemplate, deleteTemplate } from '../api';

const s = {
  title: { fontSize: '20px', fontWeight: '500', color: '#111', marginBottom: '4px' },
  sub: { fontSize: '13px', color: '#888', marginBottom: '20px' },
  topbar: { display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: '20px' },
  btnPrimary: { padding: '8px 16px', fontSize: '13px', borderRadius: '8px', border: 'none', background: '#111', color: '#fff', cursor: 'pointer' },
  btnSuccess: { padding: '8px 16px', fontSize: '13px', borderRadius: '8px', border: 'none', background: '#3B6D11', color: '#fff', cursor: 'pointer' },
  btn: { padding: '6px 12px', fontSize: '12px', borderRadius: '6px', border: '0.5px solid #ccc', background: '#fff', cursor: 'pointer', marginLeft: '6px' },
  btnDanger: { padding: '6px 12px', fontSize: '12px', borderRadius: '6px', border: '0.5px solid #f7c1c1', background: '#fff', color: '#A32D2D', cursor: 'pointer', marginLeft: '6px' },
  card: { background: '#fff', border: '0.5px solid #e0e0d8', borderRadius: '12px', padding: '16px', marginBottom: '12px' },
  cardTitle: { fontSize: '14px', fontWeight: '500', color: '#111', marginBottom: '14px' },
  label: { fontSize: '12px', color: '#666', marginBottom: '5px', marginTop: '10px' },
  hint: { fontSize: '11px', color: '#aaa', fontWeight: '400' },
  input: { width: '100%', fontSize: '13px', padding: '8px 10px', borderRadius: '8px', border: '0.5px solid #ccc', background: '#fff', outline: 'none' },
  editorWrap: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0', border: '0.5px solid #ccc', borderRadius: '8px', overflow: 'hidden', marginBottom: '10px' },
  editorHeader: { padding: '7px 12px', background: '#f5f5f0', borderBottom: '0.5px solid #ccc', fontSize: '12px', fontWeight: '500', color: '#666' },
  editorTextarea: { width: '100%', fontSize: '12px', padding: '10px', border: 'none', borderRight: '0.5px solid #ccc', resize: 'none', minHeight: '220px', fontFamily: 'monospace', lineHeight: '1.6', outline: 'none', background: '#fff' },
  plainTextarea: { width: '100%', fontSize: '13px', padding: '8px 10px', borderRadius: '8px', border: '0.5px solid #ccc', background: '#fff', resize: 'vertical', minHeight: '80px', lineHeight: '1.6', outline: 'none', fontFamily: 'inherit' },
  templateRow: { display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 0', borderBottom: '0.5px solid #e0e0d8' },
  templateName: { fontSize: '14px', fontWeight: '500', color: '#111' },
  templateSub: { fontSize: '12px', color: '#888', marginTop: '2px' },
  success: { background: '#eaf3de', border: '0.5px solid #c0dd97', borderRadius: '8px', padding: '10px 14px', fontSize: '13px', color: '#3B6D11', marginBottom: '12px' },
  error: { background: '#fcebeb', border: '0.5px solid #f7c1c1', borderRadius: '8px', padding: '10px 14px', fontSize: '13px', color: '#A32D2D', marginBottom: '12px' },
  infoBox: { background: '#e6f1fb', border: '0.5px solid #b5d4f4', borderRadius: '8px', padding: '10px 14px', fontSize: '12px', color: '#185FA5', marginBottom: '16px' },
  divider: { border: 'none', borderTop: '0.5px solid #e0e0d8', margin: '16px 0' },
  footerBtns: { display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '16px' },
  emptyBox: { textAlign: 'center', padding: '40px', color: '#888', fontSize: '13px' },
  previewBox: { background: '#f5f5f0', borderRadius: '8px', padding: '14px', fontSize: '13px', lineHeight: '1.7', marginTop: '8px', maxHeight: '200px', overflow: 'auto' },
};

function TemplateEditor({ template, onSave, onCancel, isEditing }) {
  const [name, setName] = useState(template?.name || '');
  const [subject, setSubject] = useState(template?.subject || '');
  const [bodyHtml, setBodyHtml] = useState(template?.body_html || '');
  const [bodyPlain, setBodyPlain] = useState(template?.body_plain || '');
  const [err, setErr] = useState('');
  const previewRef = useRef(null);

  useEffect(() => {
    if (previewRef.current) {
      previewRef.current.srcdoc = `<html><body style="font-family:-apple-system,sans-serif;padding:16px;margin:0;font-size:13px;line-height:1.7;color:#111;">${bodyHtml || '<p style="color:#aaa;">HTML preview will appear here...</p>'}</body></html>`;
    }
  }, [bodyHtml]);

  const handleSave = () => {
    if (!name.trim()) return setErr('Template name is required');
    setErr('');
    onSave({ name, subject, body_html: bodyHtml, body_plain: bodyPlain });
  };

  return (
    <div style={s.card}>
      <div style={s.cardTitle}>{isEditing ? 'Edit template' : 'New template'}</div>

      <div style={s.infoBox}>
        Only the template name is required. Subject, HTML body and plain text are all optional.
      </div>

      {err && <div style={s.error}>{err}</div>}

      <div style={s.label}>Template name <span style={{ color: '#A32D2D' }}>*</span></div>
      <input style={s.input} placeholder="e.g. Black Friday offer" value={name} onChange={e => setName(e.target.value)} />

      <div style={s.label}>Subject line <span style={s.hint}>(optional)</span></div>
      <input style={s.input} placeholder="Leave empty if not needed" value={subject} onChange={e => setSubject(e.target.value)} />

      <div style={s.label}>HTML body <span style={s.hint}>(optional)</span></div>
      <div style={s.editorWrap}>
        <div>
          <div style={s.editorHeader}>HTML editor</div>
          <textarea
            style={s.editorTextarea}
            placeholder="Paste your HTML here... or leave empty"
            value={bodyHtml}
            onChange={e => setBodyHtml(e.target.value)}
            spellCheck={false}
          />
        </div>
        <div>
          <div style={s.editorHeader}>Live preview</div>
          <iframe
            ref={previewRef}
            style={{ width: '100%', minHeight: '220px', border: 'none' }}
            title="preview"
            sandbox="allow-same-origin"
          />
        </div>
      </div>

      <div style={s.label}>Plain text <span style={s.hint}>(optional)</span></div>
      <textarea
        style={s.plainTextarea}
        placeholder="Plain text version... or leave empty"
        value={bodyPlain}
        onChange={e => setBodyPlain(e.target.value)}
      />

      <div style={s.footerBtns}>
        <button style={s.btn} onClick={onCancel}>Cancel</button>
        <button style={s.btnSuccess} onClick={handleSave}>
          {isEditing ? 'Save changes' : 'Save template'}
        </button>
      </div>
    </div>
  );
}

export default function Templates() {
  const [templates, setTemplates] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [msg, setMsg] = useState(null);
  const [err, setErr] = useState(null);

  const load = async () => {
    try {
      const res = await getTemplates();
      setTemplates(res.data);
    } catch (e) { console.error(e); }
  };

  useEffect(() => { load(); }, []);

  const showMsg = (m) => { setMsg(m); setTimeout(() => setMsg(null), 4000); };
  const showErr = (e) => { setErr(e); setTimeout(() => setErr(null), 4000); };

  const handleCreate = async (data) => {
    try {
      await createTemplate(data);
      showMsg('Template saved!');
      setShowForm(false);
      load();
    } catch (e) { showErr('Error saving template'); }
  };

  const handleUpdate = async (data) => {
    try {
      await updateTemplate(editingTemplate.id, data);
      showMsg('Template updated!');
      setEditingTemplate(null);
      load();
    } catch (e) { showErr('Error updating template'); }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete template "${name}"?`)) return;
    try {
      await deleteTemplate(id);
      showMsg('Template deleted');
      load();
    } catch (e) { showErr('Error deleting template'); }
  };

  return (
    <div>
      <div style={s.topbar}>
        <div>
          <div style={s.title}>Templates</div>
          <div style={s.sub}>Create and manage reusable email templates</div>
        </div>
        {!showForm && !editingTemplate && (
          <button style={s.btnPrimary} onClick={() => setShowForm(true)}>+ New template</button>
        )}
      </div>

      {msg && <div style={s.success}>{msg}</div>}
      {err && <div style={s.error}>{err}</div>}

      {showForm && (
        <TemplateEditor
          onSave={handleCreate}
          onCancel={() => setShowForm(false)}
          isEditing={false}
        />
      )}

      {editingTemplate && (
        <TemplateEditor
          template={editingTemplate}
          onSave={handleUpdate}
          onCancel={() => setEditingTemplate(null)}
          isEditing={true}
        />
      )}

      <div style={s.card}>
        <div style={s.cardTitle}>Saved templates ({templates.length})</div>
        {templates.length === 0 && (
          <div style={s.emptyBox}>No templates yet. Create one above.</div>
        )}
        {templates.map(t => (
          <div key={t.id}>
            <div style={s.templateRow}>
              <div style={{ flex: 1, cursor: 'pointer' }} onClick={() => setExpandedId(expandedId === t.id ? null : t.id)}>
                <div style={s.templateName}>{t.name}</div>
                <div style={s.templateSub}>
                  {t.subject ? `Subject: ${t.subject}` : 'No subject'}
                  {' · '}
                  {t.body_html ? 'Has HTML' : t.body_plain ? 'Plain text only' : 'No body'}
                  {' · '}
                  {new Date(t.created_at).toLocaleDateString()}
                </div>
              </div>
              <button style={s.btn} onClick={() => { setEditingTemplate(t); setShowForm(false); }}>Edit</button>
              <button style={s.btnDanger} onClick={() => handleDelete(t.id, t.name)}>Delete</button>
            </div>
            {expandedId === t.id && t.body_html && (
              <div style={s.previewBox} dangerouslySetInnerHTML={{ __html: t.body_html }} />
            )}
            {expandedId === t.id && !t.body_html && t.body_plain && (
              <div style={s.previewBox}>{t.body_plain}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
